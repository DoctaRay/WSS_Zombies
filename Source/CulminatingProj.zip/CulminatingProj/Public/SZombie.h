// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "SCharacter.h"
#include "SZombie.generated.h"

/**
 * 
 */
UCLASS()
class CULMINATINGPROJ_API ASZombie : public ASCharacter
{
	GENERATED_BODY()
	
};
